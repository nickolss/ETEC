fun main(args: Array<String>) {
    val sobre = Sobreposicao()

    println("Quadrado de 3: ${sobre.quadrado(3)}")
    println("Quadrado de 3.5: ${sobre.quadrado(3.5)}")
}
