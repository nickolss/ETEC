class Sobreposicao {

    fun quadrado(numero: Int) : Int{
        return numero * numero
    }

    fun quadrado(numero : Double) : Double{
        return numero * numero
    }
}