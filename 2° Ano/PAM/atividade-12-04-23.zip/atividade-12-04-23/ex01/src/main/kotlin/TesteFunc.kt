fun main(args: Array<String>) {
    var funcionario1 = Funcionario()

    funcionario1.nascimento = 2007
    funcionario1.salario = 8500.0

    funcionario1.informarSalario()
    funcionario1.informarIdade()
}