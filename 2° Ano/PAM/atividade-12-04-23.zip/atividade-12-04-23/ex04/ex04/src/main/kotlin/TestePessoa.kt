fun main(args: Array<String>) {
    val pessoa1 = Pessoa()
    pessoa1.cadastrarPessoa()
    pessoa1.listarCadastro()
}