/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula5;
import javax.swing.JOptionPane;
/**
 *
 * @author FATEC ZONA LESTE
 */
public class Slide2 {
    public static void main(String[] args) {
        String numero = JOptionPane.showInputDialog("Digite um número");
        JOptionPane.showMessageDialog(null, "O número digitado foi: " + numero);
    }
}
