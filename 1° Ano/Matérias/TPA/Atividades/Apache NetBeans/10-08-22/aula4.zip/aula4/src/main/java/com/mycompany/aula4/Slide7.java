/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula4;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Slide7 {
    public static void main (String[] args){
        //declara um int e atribui um valor
        int idade = 25;
        //declara um float e depois atribui um valor
        float valor;
        valor = 1.99f;
        //declarando um boolean
        boolean verdadeiroOuFalso = false;
        verdadeiroOuFalso = true;
        //declarando um Char
        char letraA = 'A';
        letraA = 65;   //Valor ASCII para 'A'
        letraA = '\u0041'; //valor unicode para 'A'
        //declarando um byte
        byte b = 127;
        //declarando um short
        short s = 1024;
        //declarando um long
        long l = 1234567890;
        //declarando um double
        double d = 100.0;
        //declaração multipla
        int var1=0, var2=1, var3=2, var4=3;
        
    }
}
