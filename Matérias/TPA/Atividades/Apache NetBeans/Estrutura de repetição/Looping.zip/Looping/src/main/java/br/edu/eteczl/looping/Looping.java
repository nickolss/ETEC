package br.edu.eteczl.looping;

/**
 *
 * @author Wagner Lucca
 */
public class Looping 
{

    public static void main(String[] args) 
    {
      System.out.println("Exemplo de Estrutura de Repetição!");
        
      System.out.println("\nExibir números de 1 a 10:\n");
       
      /**
       * =======================================================================
       *                Exemplo de For:
       * =======================================================================
       */
      
      System.out.println("Aqui um exemplo de FOR...");
      
      for (int cont = 1 ; cont <= 10; cont++)
      {
        System.out.println(cont);
      }
      
      System.out.println("");
      
      /**
       * =======================================================================
       *                Exemplo de While:
       * =======================================================================
       */
      
      System.out.println("Aqui um exemplo de While...");
        
      int cont = 1;
      
      while(cont <= 10)
      {
        System.out.println(cont);
        
        cont++;
      }
      
      System.out.println("");
      
            /**
       * =======================================================================
       *                Exemplo de Do...While:
       * =======================================================================
       */
      
      System.out.println("Aqui um exemplo de Do...While...");
        
      cont = 1;
      
      do
      {        
        System.out.println(cont);
        
        cont++;
      }
      while (cont <= 10);

      System.out.println("");
      
    }
}
