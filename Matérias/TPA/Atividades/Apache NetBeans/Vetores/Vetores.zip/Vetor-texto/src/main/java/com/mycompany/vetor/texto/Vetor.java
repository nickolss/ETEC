/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vetor.texto;

/**
 *
 * @author dti
 */
class Vetor {
    void exibirVetorPorLetra(String[]_vetor){
        for (int cont = 0; cont < _vetor.length; cont++) {
            System.out.println("Indice => " + cont + "/ Letra =>" + _vetor[cont]);
        }
    }
    
    void exibirVetorPorLinha(String[] _vetor){
        System.out.print("Nome: ");
        
        for (int cont = 0; cont < _vetor.length; cont++) {
            System.out.print(_vetor[cont]);
        }
    }
}
